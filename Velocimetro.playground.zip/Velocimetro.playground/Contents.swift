//: Playground - noun: a place where people can play

import UIKit

enum Velocidades: Int {
    case Apagado = 0
    case VelocidadBaja = 20
    case VelocidadMedia = 50
    case VelocidadAlta = 120
    init(velocidadInicial : Velocidades) {
        self = velocidadInicial
    }
}


class Auto {
    var velocidad: Velocidades
    
    init()
    {
        //velocidad = Velocidades(velocidadInicial: .Apagado)
        velocidad = .Apagado
        print("\(velocidad.rawValue), Apagado")
     }
    func cambioDeVelocidad() -> (actual: Int, velocidadEnCadena: String) {
        var cadena: String = " "
        switch velocidad.rawValue {
            case 0: velocidad = .VelocidadBaja
                    cadena = "Velocidad baja"
            case 20: velocidad = .VelocidadMedia
                    cadena = "Velocidad media"
            case 50: velocidad = .VelocidadAlta
                    cadena = "Velocidad alta"
            case 120: velocidad = .VelocidadMedia
                    cadena = "Velocidad media"
            default: break
            }
        return(velocidad.rawValue, cadena)
    }
}
    var auto = Auto()

    for index in 1...20{
        var resultado = auto.cambioDeVelocidad()
        print("\(resultado.actual), \(resultado.velocidadEnCadena)")
    }


 